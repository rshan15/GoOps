import { Module } from './module';
export declare type Hero = {
    id: string;
};
export declare const heroModule: Module;
export default heroModule;
