import { Module } from './module';
export declare type Dataset = Record<string, string>;
export declare const datasetModule: Module;
export default datasetModule;
